// Имя пользователя, сообщения которого нужно удалять (в нижнем регистре для точной проверки)
const TARGET_USER = "mcl_6667".toLowerCase();

function removeTargetMessages() {
  // Находим все строки чата Twitch (селектор может меняться, но стандартный класс chat-line__message стабилен)
  const messages = document.querySelectorAll('.chat-line__message');

  messages.forEach(msg => {
    // Ищем элемент с именем пользователя внутри сообщения
    const userElement = msg.querySelector('.chat-author__display-name, .chat-line__username');
    
    if (userElement) {
      const username = userElement.textContent.trim().toLowerCase();
      
      if (username === TARGET_USER) {
        // Скрываем блок сообщения
        msg.style.display = 'none';
      }
    }
  });
}

// Запускаем наблюдатель за изменениями DOM (так как чат постоянно динамически обновляется)
const observer = new MutationObserver((mutations) => {
  for (let mutation of mutations) {
    if (mutation.addedNodes.length > 0) {
      removeTargetMessages();
      break;
    }
  }
});

// Начинаем следить за контейнером тела страницы
observer.observe(document.body, {
  childList: true,
  subtree: true
});

// Первичный запуск на случай, если сообщения уже загружены
removeTargetMessages();